import{W as n}from"./index-C-YbT6RQ.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
