import{W as n}from"./index-C1MRgpyl.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
