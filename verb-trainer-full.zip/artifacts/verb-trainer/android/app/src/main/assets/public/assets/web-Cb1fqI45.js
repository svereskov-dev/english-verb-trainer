import{W as n}from"./index-DnyTh-Fs.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
