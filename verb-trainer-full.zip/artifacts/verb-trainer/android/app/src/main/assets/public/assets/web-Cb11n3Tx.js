import{W as n}from"./index-DaF6izz9.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
