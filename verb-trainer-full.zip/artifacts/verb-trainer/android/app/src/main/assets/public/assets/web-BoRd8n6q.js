import{W as n}from"./index-CvSV9MUg.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
