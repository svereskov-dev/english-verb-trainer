import{W as n}from"./index-Ctdr6ZOy.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
