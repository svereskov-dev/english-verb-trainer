import{W as n}from"./index-DlIIDRN_.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
