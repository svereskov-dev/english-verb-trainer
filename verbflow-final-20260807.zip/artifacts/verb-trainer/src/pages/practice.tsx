import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useExerciseSession } from "../hooks/useExerciseSession";
import { useKeyboardVisible } from "../hooks/useKeyboardVisible";
import { useAudioFeedback } from "../hooks/useAudioFeedback";
import { ExerciseCard } from "../components/ExerciseCard";
import { AnswerInput } from "../components/AnswerInput";
import { LetterBuilder } from "../components/LetterBuilder";
import { ProgressBar } from "../components/ProgressBar";
import { TrainingMenu, DEFAULT_SESSION } from "../components/TrainingMenu";
import { SessionConfig } from "../engine/exercises";
import { SkipForward, ChevronRight } from "lucide-react";
import { BottomNav } from "../components/BottomNav";
import { Button } from "../components/ui/button";
import { cn } from "../lib/utils";

const CONFIG_KEY = "practice_config";
const CONFIG_DATE_KEY = "practice_config_date";

function isNewDay(): boolean {
  const saved = localStorage.getItem(CONFIG_DATE_KEY);
  if (!saved) return true;
  const savedDate = new Date(parseInt(saved, 10));
  const now = new Date();
  return (
    savedDate.getFullYear() !== now.getFullYear() ||
    savedDate.getMonth() !== now.getMonth() ||
    savedDate.getDate() !== now.getDate()
  );
}

function loadPersistedConfig(): SessionConfig | null {
  if (isNewDay()) {
    localStorage.removeItem(CONFIG_KEY);
    return null;
  }
  try {
    const raw = localStorage.getItem(CONFIG_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as SessionConfig;
    // Backward compatibility: old configs without selectedIds
    if (!parsed.selectedIds) {
      parsed.selectedIds = [parsed.id];
    }
    // Backward compatibility: old configs without userCustomized
    if (parsed.userCustomized === undefined) {
      parsed.userCustomized = true;
    }
    return parsed;
  } catch {
    return null;
  }
}

function savePersistedConfig(config: SessionConfig) {
  try {
    localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
    localStorage.setItem(CONFIG_DATE_KEY, Date.now().toString());
  } catch {
    // ignore
  }
}

export default function Practice() {
  const [, navigate] = useLocation();
  const [config, setConfig]               = useState<SessionConfig>(
    loadPersistedConfig() ?? DEFAULT_SESSION
  );
  const [submittedValue, setSubmittedValue] = useState("");
  const [pendingAnswer, setPendingAnswer]   = useState("");

  // Keyboard-aware compact layout
  const keyboardVisible = useKeyboardVisible();

  const {
    currentExercise,
    dailyCorrect,
    dailyIncorrect,
    streak,
    feedback,
    showAnswer,
    submitAnswer,
    nextExercise,
    skipExercise,
    dailyGoal,
    noMistakes,
    reviewExhausted,
    reviewComplete,
    onClearReview,
    exerciseSeq,
    getReviewQueueLength,
  } = useExerciseSession(config);

  // ── Check for a Mistakes-review session on first load ───────────────────
  useEffect(() => {
    const raw = sessionStorage.getItem("mistakeReview");
    if (!raw) return;
    try {
      const data = JSON.parse(raw) as {
        verbs: string[];
        mistakeIds?: string[];
        mode: string;
      };
      if (data.verbs && data.verbs.length > 0) {
        setConfig({
          id: "mistake-review",
          label: "Review Mistakes",
          groupLabel: "Mistakes Review",
          selectedIds: ["mistakes"],
          exerciseTypes: ["verbform", "irregular"],
          verbPool: "all",
          reviewVerbs: data.verbs,
          // Prefer specific mistake IDs so exercises match the exact
          // verb + type + tense/form that was originally answered incorrectly.
          reviewMistakeIds: data.mistakeIds && data.mistakeIds.length > 0
            ? data.mistakeIds
            : undefined,
          contextEnabled: false,
          userCustomized: true,
        });
      }
    } catch {
      sessionStorage.removeItem("mistakeReview");
    }
  }, []);

  // ── Persist config changes to localStorage ──────────────────────────────
  // Never persist the transient review config — if the user returns to Practice
  // later it should open as a normal practice session, not restart a review.
  useEffect(() => {
    if (config.id === "mistake-review") return;
    savePersistedConfig(config);
  }, [config]);

  // ── Auto-navigate when Mistakes Review completes ─────────────────────────
  // reviewComplete fires as soon as the last mistake is answered correctly.
  // We do a full teardown before navigating so Practice comes up clean.
  useEffect(() => {
    if (!reviewComplete) return;
    // Reset the practice page's own UI state.
    setSubmittedValue("");
    setPendingAnswer("");
    // Reset to the last normal session (or default) so returning to Practice
    // never re-enters review mode.
    const normal = loadPersistedConfig() ?? DEFAULT_SESSION;
    setConfig(normal);
    // Clear all review bookkeeping inside the hook.
    onClearReview();
    // Navigate to the Mistakes screen — it will already show the empty state
    // because the hook dispatched "mistakes-updated" when the last record
    // had its lastFailureDate cleared.
    navigate("/mistakes");
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reviewComplete]);

  // ── Success sound ────────────────────────────────────────────────────────────
  const { playSuccess } = useAudioFeedback();
  useEffect(() => {
    if (feedback === "correct") playSuccess();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [feedback]);

  const handleCheck = () => {
    if (!pendingAnswer.trim() || feedback !== null) return;
    setSubmittedValue(pendingAnswer);
    submitAnswer(pendingAnswer);
  };

  // ── Letter Builder callbacks ─────────────────────────────────────────────────
  const handleLetterBuilderSuccess = (answer: string) => {
    setSubmittedValue(answer);
    submitAnswer(answer);
  };

  const handleLetterBuilderFailure = () => {
    // Submit a clearly-wrong string so the existing failure flow fires
    submitAnswer("__lb_fail__");
  };

  const handleSkip = () => {
    setSubmittedValue("");
    setPendingAnswer("");

    // Case 2: last (or only) remaining mistake in the review queue.
    // Skipping it would just loop the same exercise forever, so auto-exit
    // Mistakes Review and return to the user's normal Practice session.
    // The mistake is NOT marked solved — it stays in the Mistakes list.
    if (config.id === "mistake-review" && getReviewQueueLength() <= 1) {
      const normal = loadPersistedConfig() ?? DEFAULT_SESSION;
      setConfig(normal);
      onClearReview();
      return;
    }

    // Case 1: other mistakes remain — normal skip, stay in Mistakes Review.
    skipExercise();
  };

  const handleNext = () => {
    setSubmittedValue("");
    setPendingAnswer("");
    nextExercise();
  };

  const handleSelectConfig = (next: SessionConfig) => {
    setSubmittedValue("");
    setPendingAnswer("");
    setConfig(next);
    // If user manually picks a mode, clear the transient review session
    onClearReview();
  };

  // Fires immediately when the user flips a toggle (Context / Letter Builder)
  // inside the Training Mode sheet — no need to press "Start Training".
  const handleImmediateToggle = (next: SessionConfig) => {
    setSubmittedValue("");
    setPendingAnswer("");
    setConfig(next);
    // Deliberately no onClearReview() — toggle changes should not discard
    // any in-progress review queue.
  };

  const handleOpenTenses = () => {
    // Pass the single tense being practiced as context, if applicable
    const singleTense = config.tenses?.length === 1 ? config.tenses[0] : null;
    try {
      if (singleTense) {
        sessionStorage.setItem("tensesContext", JSON.stringify({ tenseId: singleTense }));
      } else {
        sessionStorage.removeItem("tensesContext");
      }
    } catch { /* ignore */ }
    navigate("/tenses");
  };

  // ── Mistakes mode with nothing to review ───────────────────────────────────
  if (noMistakes) {
    return (
      <div className="h-[100dvh] overflow-hidden bg-background nav-safe-pad pt-safe flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center p-8 gap-5 text-center overflow-y-auto">
          <div className="text-6xl">🎉</div>
          <div>
            <h2 className="text-xl font-bold mb-1">No mistakes to review</h2>
            <p className="text-muted-foreground text-sm">
              Keep practicing — items you miss will appear here.
            </p>
          </div>
          <TrainingMenu current={config} onSelect={handleSelectConfig} onImmediateToggle={handleImmediateToggle} />
        </div>
        <BottomNav />
      </div>
    );
  }

  // ── Review session finished (all verbs now correct) ───────────────────────
  if (reviewExhausted) {
    return (
      <div className="h-[100dvh] overflow-hidden bg-background nav-safe-pad pt-safe flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center p-8 gap-5 text-center overflow-y-auto">
          <div className="text-6xl">🎉</div>
          <div>
            <h2 className="text-xl font-bold mb-1">Review Complete</h2>
            <p className="text-muted-foreground text-sm">
              You answered correctly on all verbs from this review.
            </p>
          </div>
          <TrainingMenu current={config} onSelect={handleSelectConfig} onImmediateToggle={handleImmediateToggle} />
        </div>
        <BottomNav />
      </div>
    );
  }

  if (!currentExercise) return null;

  const showingFeedback = feedback !== null;

  return (
    /* overflow-hidden is critical: it prevents any child overflow from
       escaping to document level and growing the layout across mode switches. */
    <div className={cn(
      "h-[100dvh] overflow-hidden bg-background pt-safe flex flex-col",
      keyboardVisible ? "" : "nav-safe-pad"
    )}>
      {/* Header — compact when keyboard is open */}
      <div className={cn(
        "w-full max-w-3xl mx-auto",
        keyboardVisible ? "px-3 pt-1 pb-0.5" : "px-4 pt-2 pb-1"
      )}>
        {/* Row 1: Training Mode (left) | English Tenses (right) */}
        <div className="flex items-center justify-between gap-2 min-w-0">
          <TrainingMenu
            current={config}
            onSelect={handleSelectConfig}
            onImmediateToggle={handleImmediateToggle}
            compact={keyboardVisible}
          />
          {!keyboardVisible && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleOpenTenses}
              className="rounded-full shrink-0 gap-1.5 font-semibold border-primary/30 hover:border-primary/50 hover:bg-card hover:text-foreground shadow-sm"
              aria-label="English Tenses reference"
            >
              <span>English Tenses</span>
              <ChevronRight size={13} className="text-muted-foreground -ml-0.5" />
            </Button>
          )}
        </div>

        {/* Row 2: Daily Progress block — visible only when keyboard is closed.
            Sits naturally below the top controls instead of at the screen edge. */}
        {!keyboardVisible && (
          <ProgressBar
            current={dailyCorrect + dailyIncorrect}
            total={dailyGoal}
            correct={dailyCorrect}
            incorrect={dailyIncorrect}
            goalReached={dailyCorrect + dailyIncorrect >= dailyGoal}
          />
        )}
      </div>

      {/* Exercise area — scrolls when keyboard is open so input stays visible */}
      <div className={cn(
        "flex-1 flex flex-col items-center w-full max-w-md mx-auto overflow-y-auto min-h-0",
        keyboardVisible
          ? "p-2 gap-2 justify-start pt-1"
          : "px-4 py-3 gap-2 justify-center"
      )}>
        <div className="w-full shrink-0">
          {/* Letter Builder needs the compact card — the letter UI is the focus,
              not the large-format verb display. */}
          <ExerciseCard
            exercise={currentExercise}
            compact={keyboardVisible || !!config.letterBuilderEnabled}
            irregularContext={
              !!config.exerciseTypes?.includes("irregular") &&
              !config.exerciseTypes?.includes("verbform")
            }
          />
        </div>

        <div className="w-full flex flex-col items-center gap-3 shrink-0">
          {config.letterBuilderEnabled ? (
            /* ── Letter Builder mode ──────────────────────────────────────── */
            !showingFeedback && (
              <LetterBuilder
                key={exerciseSeq}
                exercise={currentExercise}
                onSuccess={handleLetterBuilderSuccess}
                onFailure={handleLetterBuilderFailure}
                onSkip={handleSkip}
                compact={keyboardVisible}
              />
            )
          ) : (
            /* ── Traditional typing mode ──────────────────────────────────── */
            <AnswerInput
              key={exerciseSeq}
              onSubmit={handleCheck}
              onValueChange={setPendingAnswer}
              disabled={showingFeedback}
              feedback={feedback}
              submittedValue={submittedValue}
              compact={keyboardVisible}
              expectedAnswer={
                Array.isArray(currentExercise.answer)
                  ? currentExercise.answer[0]
                  : currentExercise.answer
              }
            />
          )}

          {!config.letterBuilderEnabled && !showingFeedback && (
            <>
              <Button
                onClick={handleCheck}
                disabled={!pendingAnswer.trim()}
                className={cn(
                  "w-full max-w-md font-semibold",
                  keyboardVisible ? "h-10 text-sm" : "h-12 text-base"
                )}
                data-testid="button-check"
              >
                Check
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSkip}
                className={cn(
                  "text-muted-foreground hover:text-foreground gap-1.5",
                  keyboardVisible && "text-xs h-8 px-2"
                )}
                data-testid="button-skip"
              >
                <SkipForward size={keyboardVisible ? 12 : 14} />
                Skip
              </Button>
            </>
          )}

          {showingFeedback && (
            <>
              <div className="flex flex-col items-center justify-center gap-1">
                {showAnswer && (
                  <div className="text-center animate-in fade-in slide-in-from-bottom-2 duration-200">
                    <span className="text-muted-foreground text-sm">Correct: </span>
                    <span className="text-xl font-bold text-green-400">{showAnswer}</span>
                  </div>
                )}
              </div>
              <Button
                onClick={handleNext}
                className={cn(
                  "w-full max-w-md font-semibold",
                  keyboardVisible ? "h-10 text-sm" : "h-12 text-base"
                )}
                data-testid="button-next"
              >
                Next →
              </Button>
            </>
          )}
        </div>
      </div>

      {!keyboardVisible && <BottomNav />}
    </div>
  );
}
